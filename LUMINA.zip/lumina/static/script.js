let tasks = [];
let POMODORO_DURATION = 1500; // 25 minutes
let SHORT_BREAK_DURATION = 300; // 5 minutes
let LONG_BREAK_DURATION = 600; // 10 minutes

let pomodoroDuration = POMODORO_DURATION;
let shortBreakDuration = SHORT_BREAK_DURATION;
let longBreakDuration = LONG_BREAK_DURATION;

let currentDuration = POMODORO_DURATION;
let timerInterval;

document.getElementById("startButton").addEventListener("click", toggleTimer);
document.getElementById("resetButton").addEventListener("click", resetTimer);

// Sets functions for starting and pausing the timer
function toggleTimer() {
  const startButton = document.getElementById("startButton");

  if (startButton.textContent === "Start") {
    startButton.textContent = "Pause";
    startButton.classList.add("pause");
    timerInterval = setInterval(updateTimer, 1000);
  } else {
    startButton.textContent = "Start";
    startButton.classList.remove("pause");
    clearInterval(timerInterval);
  }
}

// Sets function to update the timer as time counts down.
function updateTimer() {
  const timerDisplay = document.getElementById("timer");
  const minutes = Math.floor(currentDuration / 60);
  const seconds = currentDuration % 60;

  const formattedTime = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  timerDisplay.textContent = formattedTime;

  if (currentDuration <= 0) {
    // Timer has reached zero, play the selected sound
    playSelectedSound();
    resetTimer();
  } else {
    currentDuration--;
  }
}

// plays the sound that the user selected in settings, will default to sound 1.
function playSelectedSound() {
  const selectedSound = document.getElementById("selectSound").value;
  const audioElement = new Audio(selectedSound);

  // Play the selected sound and handle the promise
  audioElement.play().then(() => {
    // Playback finished successfully
    console.log(`Successfully played: ${selectedSound}`);
  }).catch((error) => {
    // Playback failed
    console.error(`Failed to play: ${selectedSound}`, error);
  });
}
function resetTimer() {
  clearInterval(timerInterval);
  // Reset the timer to the initial time (25 minutes)
  currentDuration = POMODORO_DURATION;
  document.getElementById("startButton").textContent = "Start";
  document.getElementById("startButton").classList.remove("pause");
}


function stopTimer() {
  clearInterval(timer);
}


// code to open the register popup when clicked on the button.
function openRegisterPopup() {
  const registerPopup = document.getElementById("registerPopup");
  registerPopup.style.display = "block";
}

function closeRegisterPopup() {
  const registerPopup = document.getElementById("registerPopup");
  registerPopup.style.display = "none";
}

// resets the timer when the reset icon is pressed
function resetTimer() {
  console.log("resetTimer called");
  console.log("currentDuration:", currentDuration);
  startButton.textContent = "Start";
  startButton.classList.remove("pause");

  clearInterval(timerInterval);

  const pomodoroTime = parseInt(document.getElementById("pomodoroTime").value) * 60 || pomodoroDuration;
  const shortBreakTime = parseInt(document.getElementById("shortBreakTime").value) * 60 || shortBreakDuration;
  const longBreakTime = parseInt(document.getElementById("longBreakTime").value) * 60 || longBreakDuration;

  pomodoroDuration = pomodoroTime;
  shortBreakDuration = shortBreakTime;
  longBreakDuration = longBreakTime;

  currentDuration = pomodoroTime; // Reset to the selected timer's duration

  updateTimer(); // Update the timer display immediately
}

// opens settings when the settings cog is pressed
function openSettings() {
  const settingsPopup = document.getElementById("settingsPopup");
  settingsPopup.style.display = "block";
}

function closeSettings() {
  const settingsPopup = document.getElementById("settingsPopup");
  settingsPopup.style.display = "none";
}

function openTab(tabName) {
  const tabs = document.querySelectorAll(".tab-content");
  tabs.forEach(tab => tab.classList.remove("active"));
  const tabButtons = document.querySelectorAll(".tab");
  tabButtons.forEach(button => button.classList.remove("active"));

  document.getElementById(tabName).classList.add("active");
  const activeButton = document.querySelector(`.tab[data-tab="${tabName}"]`);
  activeButton.classList.add("active");
}

function handleTimerButtonClick(buttonId, duration) {
  const buttons = document.querySelectorAll(".rounded-button");
  buttons.forEach(button => button.classList.remove("active"));

  const clickedButton = document.getElementById(buttonId);
  clickedButton.classList.add("active");

  currentDuration = duration;
  updateTimer();
}
const tabs = document.querySelectorAll(".tab");
  tabs.forEach(tab => {
    tab.addEventListener("click", function () {
      tabs.forEach(t => t.classList.remove("clicked"));
      this.classList.add("clicked");
    });
  });

function toggleSettings() {
  const settingsPopup = document.getElementById("settingsPopup");

  if (settingsPopup.style.display === "block") {
    settingsPopup.style.display = "none";
  } else {
    settingsPopup.style.display = "block";
  }
}

function saveChanges() {
  resetTimer();
  closeSettings();
}

// Function to handle button clicks for timers
function handleTimerButtonClick(buttonId) {
  const buttons = document.querySelectorAll(".rounded-button");
  buttons.forEach(button => button.classList.remove("active"));

  const clickedButton = document.getElementById(buttonId);
  clickedButton.classList.add("active");

  // Update the current timer duration based on the input values
  const pomodoroTime = parseInt(document.getElementById("pomodoroTime").value) * 60 || POMODORO_DURATION;
  const shortBreakTime = parseInt(document.getElementById("shortBreakTime").value) * 60 || SHORT_BREAK_DURATION;
  const longBreakTime = parseInt(document.getElementById("longBreakTime").value) * 60 || LONG_BREAK_DURATION;

  switch (buttonId) {
    case "pomodoroButton":
      currentDuration = pomodoroTime;
      break;
    case "shortBreakButton":
      currentDuration = shortBreakTime;
      break;
    case "longBreakButton":
      currentDuration = longBreakTime;
      break;
    default:
      currentDuration = pomodoroTime;
  }

  updateTimer(); // Update the timer display immediately after changing the timer
}
function changeTheme(theme) {
  // Remove existing theme classes
  document.body.classList.remove("theme1", "theme2", "theme3");

  // Add the selected theme class
  document.body.classList.add(theme);
}
function saveChanges() {
  const selectedTheme = document.getElementById("selectTheme").value;
  changeTheme(selectedTheme);
  resetTimer();
  closeSettings();
}
document.getElementById("selectTheme").addEventListener("change", function () {
  const selectedTheme = this.value;
  changeTheme(selectedTheme);
});

document.addEventListener("DOMContentLoaded", function () {

  // Add event listeners for timer buttons
  document.getElementById("pomodoroButton").addEventListener("click", function () {
    handleTimerButtonClick("pomodoroButton");
  });
  document.getElementById("shortBreakButton").addEventListener("click", function () {
    handleTimerButtonClick("shortBreakButton");
  });
  document.getElementById("longBreakButton").addEventListener("click", function () {
    handleTimerButtonClick("longBreakButton");
  });

  document.getElementById("startButton").addEventListener("click", toggleTimer);
  document.getElementById("resetButton").addEventListener("click", resetTimer);
  document.getElementById("settingsButton").addEventListener("click", openSettings);

  window.addEventListener("click", function (event) {
    if (event.target === document.getElementById("settingsPopup")) {
      closeSettings();
    }
  });

  updateTimer();
});
function openAddTaskPopup() {
  const addTaskPopup = document.getElementById("addTaskPopup");
  addTaskPopup.style.display = "block";
}

function closeAddTaskPopup() {
  const addTaskPopup = document.getElementById("addTaskPopup");
  addTaskPopup.style.display = "none";
}

// function for the add task command
function addTask() {
  const title = document.getElementById("title").value;
  const description = document.getElementById("description").value;

  const task = { title, description };
  tasks.push(task);

  // Display the updated tasks
  displayAllTasks();

  // Close the add task popup
  closeAddTaskPopup();
}

// Function to close the add task popup
function closeAddTaskPopup() {
  const addTaskPopup = document.getElementById("addTaskPopup");
  addTaskPopup.style.display = "none";
}

// Function to display all tasks
function displayAllTasks() {
  const taskContainer = document.getElementById("taskContainer");

  // Clear existing tasks
  clearTaskContainer();

  // Display each task
  tasks.forEach(task => displayTask(task, taskContainer));
}

// Function to display a task
function displayTask(task, container) {
  // Create task element with only the task title
  const taskElement = document.createElement("div");
  taskElement.className = "task";
  taskElement.textContent = task.title;

  // Handle hover effect
  taskElement.addEventListener("mouseover", () => hoverTask(taskElement));
  taskElement.addEventListener("mouseout", () => unhoverTask(taskElement));

  // Handle task deletion
  taskElement.addEventListener("click", () => deleteTask(task));

  // Append task element to container
  container.appendChild(taskElement);
}

// Function to handle hovering over a task
function hoverTask(taskElement) {
  taskElement.style.textDecoration = "line-through";
  taskElement.style.opacity = "0.7";
}

// Function to handle unhovering over a task
function unhoverTask(taskElement) {
  taskElement.style.textDecoration = "none";
  taskElement.style.opacity = "1";
}

// Function to delete a task
function deleteTask(task) {
  tasks = tasks.filter(t => t !== task);
  displayAllTasks();
}

// Function to clear the task container
function clearTaskContainer() {
  const taskContainer = document.getElementById("taskContainer");
  taskContainer.innerHTML = "";
}

// Add event listeners for timer buttons
document.getElementById("pomodoroButton").addEventListener("click", function () {
  handleTimerButtonClick("pomodoroButton");
});


function updatePomodoroCount() {
  // Update the displayed count on the HTML element
  const pomodoroCountElement = document.getElementById("pomodoroCountDisplay");
  pomodoroCountElement.textContent = `Pomodoros This Session: ${pomodoroCount}`;
}
let pomodoroCount = 0; // Initialize pomodoro count

// Function to increment the pomodoro count
function incrementPomodoroCount() {
  pomodoroCount++;
  updatePomodoroCount();
}

// Function to decrement the pomodoro count (with a minimum of 0)
function decrementPomodoroCount() {
  pomodoroCount = Math.max(0, pomodoroCount - 1);
  updatePomodoroCount();
}

function redirectToSpotifyPlaylist() {
  const playlistURL = 'https://open.spotify.com/playlist/37i9dQZF1EIfMdgv54LYV9';

  // Open the Spotify playlist URL
  window.location.href = playlistURL;
}

function setTimerSound(selectedSound) {
  const timerSound = document.getElementById('timerSound');
  timerSound.src = `path/to/sounds/${selectedSound}`;
}

// Function to play the timer sound
function playTimerSound() {
  const timerSound = document.getElementById('timerSound');
  timerSound.play();
}

// Function to stop the timer sound
function stopTimerSound() {
  const timerSound = document.getElementById('timerSound');
  timerSound.pause();
  timerSound.currentTime = 0;
}

// Function to handle actions at the end of the timer (call this where needed)
function handleTimerEnd() {
  // Perform any other actions

  // Play the timer sound
  playTimerSound();
}
