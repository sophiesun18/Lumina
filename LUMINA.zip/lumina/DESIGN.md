Design Document
Overview
This project is a web application developed using Flask, a Python web framework, to create a task management system with user authentication. The frontend is built using HTML, CSS, and JavaScript, while the backend uses Flask for server-side logic and SQLAlchemy for interacting with a SQLite database. Below, I will discuss the technical aspects of the project and the design decisions made.

Frontend Design (styles.css)
Fonts and Styling
The application uses the "Jost Medium" font throughout the interface for a modern and consistent look.
Background images are employed for aesthetic appeal, and the cover property ensures they adapt to various screen sizes.

Layout and Flexbox
The main container (body) is set to flex-direction: column, aligning items from top to bottom. It contains all the buttons on the main panel of the screen, centering everything about the screen and making sure the timer is big.
The taskbarButton and timeBloomTitle sections have conflicting styles (justify-content and align-items), which should be addressed for consistency.

Buttons and Controls
Different button styles (rounded-button, startButton, etc.) are defined for various UI elements with hover effects for improved user experience.
Control buttons are centralized using flex properties for a cleaner layout. These were implemented through the backend with javascript, as I added functions to each of these buttons so that they would either start the timer or open a popup, etc.

Popup Design
The design incorporates popups for login, registration, and settings with fixed positioning to overlay on the main content.
Used popups instead of new tabs on a normal website to keep everything sleek and in one place, it makes it easier to design all the elements on one part of the main website.

Theming
Three themes (theme1, theme2, theme3) are defined, allowing users to switch between different background images for a personalized experience.

Responsive Design
The layout is designed to be responsive, adapting to different screen sizes for a seamless user experience.

Backend Design (app.py)
Flask Configuration
Flask is configured with a secret key for session management and a SQLite database for user data.
Used SQL to create user database where you can store usernames, passwords, and past data to retrieve so users can see past sessions.

User Model
The User model is defined with attributes for id, username, and hashed password, using SQLAlchemy for database interactions.
3 columns to be used for logins.

Routes
Three main routes are defined: '/' (index), '/login', and '/register' to handle user interactions.

User Authentication
User passwords are hashed using Werkzeug's generate_password_hash for security, and login credentials are validated against the stored hashed password.

Database Interaction
SQLAlchemy is used to interact with the SQLite database, with the User model representing the user table.

I chose to use html for the website contents, javascript for the functions of these contents, python to connect with java, and css to style the final look of the website. I found that this made the most sense for my project as I was able to easily use css to make stylistic changes while also being able to easily add functions in the javascript code. I used SQL to locally store passwords in a database but I would probably use node if I wanted to actually launch this to be a website.
